package com.delfinerija.baristaApp.entities;

import java.util.ArrayList;

public class Drink {
    private String name;

    public Drink(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
